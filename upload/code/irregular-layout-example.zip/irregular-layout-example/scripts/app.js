'use strict';

$(document).ready(function () {
  var $sl = $('#is-album-list'),
      grid;

  grid = {
    layout: [
      ['item1', 'item2', 'item3', 'item4', 'item5', 'pad1', 'pad2'],
      ['item6', 'item7', 'item8', 'item9'],
      ['item10', 'item11', 'item12', 'pad3', 'pad4','pad5'],
      ['item13', 'item14', 'item15', 'item16', 'item17', 'item18', 'pad6', 'pad7', 'pad8', 'pad9']
    ],
    colIndex: 0,
    availBox: [],

    width: function () {
      var i, w = 0, cw = [237, 237, 237, 329];
      for (i = 0; i < this.colIndex; i++) {
        w += cw[i % 4];
      }
      return w;
    },
    colOffset: function () {
      return parseInt(this.colIndex / 4) * 1040;
    },
    newCol: function () {
      var that = this;
      this.availBox = [];

      $.each(this.layout[this.colIndex % 4], function (index, val) {
        var $box = $('<li></li>').addClass(val);
        $sl.append($box);
        $box.css('left', parseInt($box.css('left')) + that.colOffset());

        if (val.indexOf('item') !== -1) {
          that.availBox.push($box);
        }
      });

      this.colIndex++;
    }
  };

  $('#js-material').children().each(function () {
    if (grid.availBox.length === 0) {
      grid.newCol();
    }

    grid.availBox.shift().append($(this));
  });
});
