import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class Test {
	public static void main (String[] args) {
		Function greet = new Function() {
			public Object apply (Object[] args) {
				String name = (String)args[0];
				System.out.println("Hello, " + name +"!");
				return null;
			}
		};
		
		greet.call("world");
		
		(new Function() {
			public Object apply (Object[] args) {
				System.out.println("Immediate function!");
				return null;
			}
		}).call();
		
		
		// map example
		Function map = new Function() {
			public Object apply (Object[] args) {
				Function fn = (Function)args[0];
				List coll = (List)args[1];
				Iterator itr = coll.iterator();
				
				List result = new ArrayList();
				
				while (itr.hasNext()) {
					result.add(fn.call(itr.next()));
				}
				return result;
			}
		};
		
		List lowercase = new ArrayList();
		lowercase.add('a');
		lowercase.add('b');
		lowercase.add('c');
		
		List uppercase = (List)map.call(new Function() {
			public Object apply (Object[] args) {
				return Character.toUpperCase((Character)args[0]);
			}
		}, lowercase);
		System.out.println((Character)uppercase.get(0));
		
		
		// reduce example	
		Function reduce = new Function() {
			public Object apply (Object[] args) {
				Function fn = (Function)args[0];
				List coll = (List)args[1];
				Iterator itr = coll.iterator();
				
				Object init = args.length == 3? args[2]: itr.next();
				while (itr.hasNext()) {
					init = fn.call(init, itr.next());
				}
				
				return init;
			}
		};		

		List nums = new ArrayList();
		nums.add(1);
		nums.add(2);
		nums.add(3);
		
		Function add = new Function() {
			public Object apply (Object[] args) {
				return (Integer)args[0] + (Integer)args[1];
			}
		};
		
		int sum1 = (Integer)reduce.call(add, nums);
		System.out.println(sum1);
		int sum2 = (Integer)reduce.call(add, nums, 5);
		System.out.println(sum2);
		
		
		// not example
		Function not = new Function() {
			public Object apply (Object[] args) {
				final Function fn = (Function)args[0];
				
				return new Function() {
					public Object apply (Object[] args) {
						return !(Boolean)fn.apply(args);
					}
				};
			}
		};
		
		Function isEven = new Function() {
			public Object apply (Object[] args) {
				return (Boolean)((Integer)args[0] % 2 == 0);
			}
		};
		System.out.println(isEven.call(2));
		System.out.println(isEven.call(3));
		
		Function isOdd = (Function)not.call(isEven);
		System.out.println(isOdd.call(2));
		System.out.println(isOdd.call(3));
		
		
		// curry��
		Function curry = new Function() {
			public Object apply (Object[] args) {
				final Function fn = (Function)args[0];
				final Object[] argument = args;
				
				return new Function() {
					public Object apply (Object[] args) {
						Object[] a = new Object[argument.length + args.length - 1];
						System.arraycopy(argument, 1, a, 0, argument.length - 1);
						System.arraycopy(args, 0, a, argument.length - 1, args.length);
						return fn.apply(a);
					}
				};
			}
		};
		Function inc = (Function)curry.call(add, 1);
		System.out.println(inc.call(5));
		
		
		// memoization
		Function memoize = new Function() {
			public Object apply (Object[] args) {
				final Function fn = (Function)args[0];
				final HashMap<String, Object> cache = new HashMap<String, Object>();
				
				return new Function() {
					public Object apply (Object[] args) {
						String key = "";
						for (Object o: args) {
							key += o.hashCode();
						}
						
						Object result = cache.get(key);
						if (result == null) {
							result = fn.apply(args);
							cache.put(key, result);
						}
						
						return result;
					}
				};
			}
		};
		
		Function verySlowComputation = new Function() {
			public Object apply (Object[] args) {
				System.out.println("Why do you call me?" + (Integer)args[0]);
				return args[0];
			}
		};
		Function memVerySlowComputation = (Function)memoize.call(verySlowComputation);
		
		verySlowComputation.call(1);
		verySlowComputation.call(1);
		
		memVerySlowComputation.call(1);
		memVerySlowComputation.call(1);
		memVerySlowComputation.call(2);
	}
}
