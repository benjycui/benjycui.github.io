
public abstract class Function {
	public abstract Object apply (Object[] args);
	
	public Object call (Object... args) {
		return apply(args);
	}
}
