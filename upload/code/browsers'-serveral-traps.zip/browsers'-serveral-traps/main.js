$(document).ready(function () {
  'use strict';

  $('input').click(function () {
    alert('Hello form CLICK!');
  });

  $('#trap1').delegate('input', 'click', function () {
    alert('Hello from DELEGATE!');
  });
});
